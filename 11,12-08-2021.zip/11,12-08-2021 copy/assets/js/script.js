/*Learn more js start*/

$(".expand-toggle").click(function (e) {
  e.preventDefault();

  var $this = $(this);
  var expandHeight = $this.prev().find(".inner-bit").height();

  if ($this.prev().hasClass("expanded")) {
    $this.prev().removeClass("expanded");
    $this.prev().attr("style", "");
    $this.html("Learn More <i class='fa fa-chevron-circle-down ml-1'></i>");
  } else {
    $this.prev().addClass("expanded");
    $this.prev().css("max-height", expandHeight);
    $this.html("Learn Less <i class='fa fa-chevron-circle-up ml-1'></i>");
  }
});

/*Learn more js end*/

/*chart js start*/

const data = [
  { name: 'Download', value: 28 },
  { name: 'Users', value: 22 },
  { name: 'Subscribes', value: 37 },
  { name: 'Products', value: 13 },
]

const colors = ['#FF8364', '#ff836433', '#F3F3F3', '#DEDEDE']

const margin = { top: 20, right: 20, bottom: 20, left: 20 },
  width = 400 - margin.right - margin.left,
  height = 400,
  radius = width / 2

const colorScale = d3.scaleOrdinal().range(colors)

const arc = d3.arc()
  .outerRadius(radius - 10)
  .innerRadius(radius - 120)

const textArc = d3.arc()
  .outerRadius(radius - 50)
  .innerRadius(radius - 50)

const pie = d3.pie()
  .sort(null)
  .value(d => d.value)

const svg = d3.select('.wrapper')
  .append('svg')
  .attr('transform', `translate(${margin.left}, 0)`)
  .attr('width', width)
  .attr('height', height)
  .append('g')
  .attr('transform', `translate(${width / 2}, ${height / 2 - 30})`)

const g = svg.selectAll('.arc')
  .data(pie(data))
  .enter().append('g')
  .attr('class', 'arc')

g.append('path')
  .attr('d', arc)
  .style('fill', d => colorScale(d.data.name))
  .style('stroke', 'white')
  .transition()
  .ease(d3.easeLinear)
  .duration(1000)
  .attrTween('d', chartTween)

// helper functions
function chartTween(b) {
  b.innerRadius = 0
  const i = d3.interpolate({ startAngle: 0, endAngle: 0 }, b)
  return function (t) { return arc(i(t)) }
}

/*chart js end*/